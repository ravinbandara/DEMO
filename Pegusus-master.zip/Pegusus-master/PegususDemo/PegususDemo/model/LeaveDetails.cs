﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PegususDemo.model
{
    class LeaveDetails
    {

     public string startdate { get;set;}
    public string enddate { get; set; }
    public string Description { get; set; }
    public string type { get; set; }
    public string accept { get; set; }
     public int tempd { get; set; }
     public string Leaveid { get; set; }

        

    }
}
