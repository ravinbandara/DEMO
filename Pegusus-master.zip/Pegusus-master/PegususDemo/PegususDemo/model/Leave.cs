﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PegususDemo.model
{
    class Leave
    {
        public int SickCount { get; set; }
        public int CasualCount { get; set; }
        public int PergnancyCount { get; set; }

        public int ErenedCount { get; set; }
        public int NoPayCount { get; set; }
        public int EncashCount { get; set; }
        public int  enablingS{ get; set; }
        public int enablingP { get; set; }
        public int enablingCas { get; set; }
        public int enablingNP { get; set; }
        public int enablingE { get; set; }
        public int enablingEn { get; set; }

    }
}
