﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PegususDemo.model
{
    class Employee
    {


        public string imageE
        {
            get;
            set;

        }
        public string Id
        {
            get;
            set;

        }
        public string Password
        {
            get;
            set;

        }
        public string FirstName
        {
            get;
            set;

        }
        public string LastName
        {
            get;
            set;

        }
        public string Department
        {
            get;
            set;

        }
        public string Designation
        {
            get;
            set;

        }
        public string Telephone
        {
            get;
            set;

        }
        public string Email
        {
            get;
            set;

        }
        public string Mobile
        {
            get;
            set;

        }
        public string Gender
        {
            get;
            set;

        }
        public string Address

        {
            get;
            set;

        }
        public string Marriage
        {
            get;
            set;

        }
        public string NumberOfChild
        {
            get;
            set;

        }


        public int TsickC
        {

            get;
            set;
        }

        public int TpregnantC
        {

            get;
            set;
        }

        public int TCasualC
        {

            get;
            set;
        }

        public int TWithoutC
        {

            get;
            set;
        }
        public int sickC{

            get;
            set;
        }

        public int pregnantC
        {

            get;
            set;
        }

        public int CasualC
        {

            get;
            set;
        }

        public int WithoutC
        {

            get;
            set;
        }
    }
}
